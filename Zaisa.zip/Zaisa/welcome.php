<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="styleslog.css">
        <title>Zaisa</title>
    </head>
    <body>
        <div class="wrapper">
            <div class="title">
                Welcome to Zaisa<br>
                You have signed up<br>
                Successfully<br><br>
            </div>
                <audio controls autoplay hidden="true">
                    <source src="tune.mpeg">
                </audio>  
            <div class="form-inner">
                <form name="form1" action="Login.php">
                    <div class="field btn">
                        <div class="btn-layer">
                        </div>
                        <input type="submit" value="Login">
                    </div>
                </form>
            </div>
        </div>        
    </body>
</html>