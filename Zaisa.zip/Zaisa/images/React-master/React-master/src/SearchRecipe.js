import React from 'react';
import styled from 'styled-components';


const Wrapper = styled.div`
    margin:0 auto;
    width:950px;
    height:80px;
`;
const searchRecipe = () =>(
<Wrapper />
);

export default searchRecipe;
