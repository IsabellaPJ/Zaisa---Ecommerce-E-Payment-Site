import React from 'react';
import styled from 'styled-components';


const RecipieBarWrapper = styled.div`
    width:950px;
    height:80px;
    margin: 0 auto;
    display:flex;
`;
const Recipie = styled.div`
    border-left: 1px solid #e3e3e3;
    width:25%;
    height:100%;
    background-color:${props => props.active ? '#8DC63F' : '#F2F2F2' };
    display: flex;
    align-items: center;
    justify-content: center;
    &:hover {
        background-color:#8DC63F;
    }
`;
const RecipieText = styled.p`
    text-align: center;
    padding: 0 25px;
    color:${props => props.active ? 'white' : 'grey' };
    font-weight:bold;
    ${Recipie}:hover & {
        color: white;
      }
`;
const recipieBar = (props) => {

    const recipie = props.recipeItem.map(item => {
        return (
            <Recipie key = {item.id} active = {props.active[item.id]} onClick = {() => props.clicked(item.id)}>
                <RecipieText active = {props.active[item.id]}>{item.recipe}</RecipieText>
            </Recipie>
        )
    })
    return (
        <RecipieBarWrapper >
            {recipie}
        </RecipieBarWrapper>
    );
}

export default recipieBar;