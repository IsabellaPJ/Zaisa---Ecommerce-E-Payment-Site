import React,{Component} from 'react';
import {ReceipeWrapper , Recipe , RecipieText} from './BannerStyle';

class BannerButtons extends Component {
    state = {
        listItems: [
            { id: '0', name: 'Home' },
            { id: '1', name: 'Demos' },
            { id: '2', name: 'Recipies' },
            { id: '3', name: 'page' },
            { id: '4', name: 'Submit Recipe' }
        ],
        activeState:[true,false,false,false]
}

clickHandler = (id) =>{
    let oldState = this.state.activestate;
    const index = oldState.findIndex(oldState =>  oldState === true);
    oldState[index] = !oldState[index];
    oldState[id] = true;
    console.log(oldState);
    this.setState({
        selectedBanneritem : {id:this.state.bannerItem[id].id,imgUrl:this.state.bannerItem[id].imgUrl,
            title:this.state.bannerItem[id].title,prepTime:this.state.bannerItem[id].prepTime,servings:this.state.bannerItem[id].servings,
            author:this.state.bannerItem[id].author
        },
        activestate:oldState,
    },
    
    )

}


render()
{
    return(

        <ReceipeWrapper>
            { this.state.bannerItem.map(bannerItem => {
            <Recipie key = {bannerItem.id} active = {this.state.activeState[bannerItem.id]} onClick = {this.clicked(bannerItem.id)}>
            <RecipieText active = {this.state.activeState[bannerItem.id]}>{bannerItem.recipe}</RecipieText>
            </Recipie>  }) }
        </ReceipeWrapper>
    );
            
}
}

export default BannerButtons;