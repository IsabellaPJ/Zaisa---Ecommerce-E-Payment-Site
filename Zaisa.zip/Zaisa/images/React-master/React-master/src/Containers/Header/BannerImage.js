import React, { Component} from 'react';
import sliderA_01 from '../../assets/images/sliderA_01.jpg';
import {BannerOverlay , BannerWrapper,BannerContent} from './Style'

class BannerImage extends Component {
    state = {

        recipeItem: [
            { id: '0', recipe: 'Mexican Grilled Corn Recipe' },
            { id: '1', recipe: 'Roast Chicken With Lemon Gravy' },
            { id: '2', recipe: 'Avocado Melon Salad With Lime Vinaigrette' },
            { id: '3', recipe: 'Chunky Beef Stew' },
        ],
        bannerItem: [
            { id: '0', imgUrl: require('../../assets/images/sliderA_01.jpg'), 
            title: 'BAKING', servings: 4, prepTime: '30 mins', author: 'BY SANDRA FORTIN' },
            { id: '1', imgUrl: require('../../assets/images/sliderA_02.jpg'), 
            title: 'CURRY', servings: 4, prepTime: '1 Hr 30 mins', author: 'BY SANDRA FORTIN' },
            { id: '2', imgUrl: require('../../assets/images/sliderA_03.jpg'), 
            title: 'SALADS', servings: 2, prepTime: '15 mins', author: 'BY SANDRA FORTIN' },
            { id: '3', imgUrl: require('../../assets/images/sliderA_04.jpg'), 
            title: 'BEEF', servings: 1, prepTime: '2 Hr 30 mins', author: 'BY SANDRA FORTIN' },
        ],
        selectedBanneritem :{
            id: '0', imgUrl: require('../../assets/images/sliderA_01.jpg'), title: 'BAKING', servings: 4, prepTime: '30 mins', author: 'BY SANDRA FORTIN'
        },

        activeState:[true,false,false,false]
    }

    render()
    {
        return(
            <Wrapper>
                <BannerWrapper>
                    <image src={sliderA_01} alt="banner image" />
                </BannerWrapper>
                <BannerOverlay>
                </BannerOverlay>

                <BannerContent>
                    <RecipieBtn>{this.state.selectedBanneritem.title}</RecipieBtn>
                    <Text>{this.state.recipeItem[this.state.selectedHeaderitem.id].recipe}</Text>
                    <ViewRecipieBtn>VIEW RECIPIE</ViewRecipieBtn>
                    <Icons>
                    <i className="fas fa-utensils" style={{ color: "white" }}> </i><IconText>${this.state.selectedBanneritem.servings} servings</IconText>
                    <i className="fas fa-clock" style={{ color: "white" }}></i><IconText>{this.state.selectedBanneritem.prepTime}</IconText>
                    <i className="fas fa-user" style={{ color: "white" }}></i><IconText>{this.state.selectedBanneritem.author}</IconText>
                    </Icons>
                </BannerContent>


            </Wrapper>
            
        )
    }

}

export default BannerImage;