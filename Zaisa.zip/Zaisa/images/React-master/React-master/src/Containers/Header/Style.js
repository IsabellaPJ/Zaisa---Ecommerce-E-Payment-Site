import styled from 'styled-components';

const BannerOverlay = styled.div`
height: 415px;
margin-top:80px;
background: #333;
width: 100%;
position: absolute;
display: block;
opacity: 0.5;
top:0;
`;

const BannerWrapper = styled.div`
    height: 415px;
    // margin-top:80px;
    position:relative;
`;


const BannerContent = styled.div`
    position: absolute;
    top: 80px;
    padding: 60px 50px;
    height: 100px;
`;